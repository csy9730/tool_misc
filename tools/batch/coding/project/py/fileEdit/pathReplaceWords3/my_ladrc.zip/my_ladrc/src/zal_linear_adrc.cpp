/***************************Copyright(c)***********************************
**                Guangzhou ZHIYUAN electronics Co.,LTD.                   
**                                                                         
**                      http://www.zlg.cn/                          
**                                                                         
**-------------File Info---------------------------------------------------
**File Name:            zal_linear_adrc.cpp
**Latest modified Date: 
**Latest Version:       
**Description:          
**                      
**-------------------------------------------------------------------------
**Created By:           Chen Shengyong
**Created Date:         2018-12-4
**Version:              v1.0.0
**Description:          ����ADRC�㷨
**                      
**-------------------------------------------------------------------------
**Modified By:          
**Modified Date:        
**Version:              
**Description:          
**                      
**************************************************************************/
#include "zal_linear_adrc.h"

#define ZAL_MAX(a,b) ((a)>=(b)?(a):(b))
#define ZAL_MIN(a,b) ((a)<=(b)?(a):(b))

ZalVoid zalLinearAdrcInit(ZalLinearAdrc *pAdrc,ZalFloat wo, ZalFloat wc, ZalFloat b0, ZalFloat dt) 
{
    zalLesoInit(&pAdrc->m_observer, wo, dt,b0);
    pAdrc->m_b = b0;
	pAdrc->m_kp = wc * wc;
	pAdrc->m_kd = wc + wc;

	pAdrc->lower = -1;
	pAdrc->upper = 1;
}

ZalVoid zalLinearAdrcSetBound(ZalLinearAdrc *pAdrc,ZalFloat lower, ZalFloat upper) 
{
	pAdrc->lower = lower;
	pAdrc->upper = upper;
}

ZalFloat zalLinearAdrcCtrlCal(ZalLinearAdrc *pAdrc,const ZalFloat* xhat, ZalFloat ref) {
	ZalFloat u0 = pAdrc->m_kp * (ref - xhat[0]) + pAdrc->m_kd * ( 0 - xhat[1] );
	return (u0 - xhat[2]) / pAdrc->m_b;
}

ZalFloat zalLinearAdrcStep(ZalLinearAdrc *pAdrc,ZalFloat ref,ZalFloat y )
{
    zalLesoStep(&pAdrc->m_observer,pAdrc->m_u,y);
	pAdrc->m_u0 = zalLinearAdrcCtrlCal(pAdrc,pAdrc->m_observer.zz, ref);
    pAdrc->m_u = ZAL_MAX(pAdrc->m_u0, pAdrc->lower  );
    pAdrc->m_u = ZAL_MIN(pAdrc->m_u, pAdrc->upper  );
    return pAdrc->m_u;
}