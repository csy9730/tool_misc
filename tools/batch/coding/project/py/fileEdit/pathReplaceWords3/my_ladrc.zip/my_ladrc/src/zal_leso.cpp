/***************************Copyright(c)***********************************
**                Guangzhou ZHIYUAN electronics Co.,LTD.                   
**                                                                         
**                      http://www.zlg.cn/                          
**                                                                         
**-------------File Info---------------------------------------------------
**File Name:            zal_leso.cpp
**Latest modified Date: 
**Latest Version:       
**Description:          
**                      
**-------------------------------------------------------------------------
**Created By:           Chen Shengyong
**Created Date:         2018-12-4
**Version:              v1.0.0
**Description:          �������Ź۲����㷨
**                      
**-------------------------------------------------------------------------
**Modified By:          
**Modified Date:        
**Version:              
**Description:          
**                      
**************************************************************************/
#include "zal_leso.h"
#include "math.h"



// 3*3����ӷ����������а����к��У�
ZalVoid mat33Add(const ZalFloat * pLeftIn,const ZalFloat *pRightIn,ZalFloat * pOut)
{
    ZalInt32 i,j;
    for (i=0;i<3;i++) // row
    {
        for (j =0;j<3;j++) // column
        {
            pOut[j+i*3] =  pLeftIn[j+i*3] + pRightIn[j+i*3];            
        }
    }
}
// 3*3�������
ZalVoid mat33Minus(const ZalFloat * pLeftIn,const ZalFloat *pRightIn,ZalFloat * pOut)
{
    ZalInt32 i,j;
    for (i=0;i<3;i++) 
    {
        for (j =0;j<3;j++) 
        {
            pOut[j+i*3] =  pLeftIn[j+i*3] -pRightIn[j+i*3];            
        }
    }
}
// 3*3����˷�
ZalVoid mat33Mupliply(const ZalFloat * pLeftIn,const ZalFloat *pRightIn,ZalFloat * pOut)
{
    ZalInt32 i,j,k;
    for (i=0;i<3;i++)
    {
        for (j =0;j<3;j++)
        {
            pOut[j+i*3] = 0;
            for (k = 0;k<3;k++){
                pOut[j+i*3] +=  pLeftIn[k+i*3] *pRightIn[j+k*3];
            }
        }
    }
}
// 3*3����� 3*2����
ZalVoid mat33Mupliply32(const ZalFloat * pLeftIn,const ZalFloat *pRightIn,ZalFloat * pOut)
{
    ZalInt32 i,j,k;
    for (i=0;i<3;i++)
    {
        for (j =0;j<2;j++)
        {
            pOut[j+i*2] = 0;
            for (k = 0;k<3;k++){
                pOut[j+i*2] +=  pLeftIn[k+i*3] *pRightIn[j+k*2];
            }
        }
    }
}
// 3*3����� 3*1����
ZalVoid mat33Mupliply31(const ZalFloat * pLeftIn,const ZalFloat *pRightIn,ZalFloat * pOut)
{
    ZalInt32 i,j,k;
    for (i=0;i<3;i++)
    {
        pOut[i] = 0;
        for (k = 0;k<3;k++){
            pOut[i] +=  pLeftIn[k+i*3] *pRightIn[k];
        }
    }
}

// 3*2����� 2*1����
ZalVoid mat32Mupliply21(const ZalFloat * pLeftIn,const ZalFloat *pRightIn,ZalFloat * pOut)
{
    ZalInt32 i,k;
    for (i=0;i<3;i++)
    {
        pOut[i] = 0;
        for (k = 0;k<2;k++){
            pOut[i] +=  pLeftIn[k+i*2] *pRightIn[k];
        }
    }
}
// 3*1����+ 3*1����
ZalVoid mat31Add(const ZalFloat * pLeftIn,const ZalFloat *pRightIn,ZalFloat * pOut)
{
    ZalInt32 i;
    for (i=0;i<3;i++)
    {
        pOut[i] =  pLeftIn[i] *pRightIn[i];
    }
}

//%%
//hh =2.5;
//wo = 0.85;
//AO = [-3*wo,1,0;-3*wo*wo ,0,1;-wo*wo*wo,0,0];
//V = [wo^2 -2*wo 1;2*wo^3 -3*wo^2 0; wo^4 -wo^3 0];
//IV = [0,0,1;-wo^-3,-wo^-2,-1/wo;3*wo^-4,2*wo^-3,wo^-2]';
//J = diag(-[wo ,wo wo]);J2(1,2)=1;J2(2,3)=1;
//EJ= expm(J*hh)
//EA =expm(AO*hh) 
//EA2= V*EJ*IV
//% zr97=norm(EA2-EA);
ZalVoid zalWodt2Exmpm(ZalFloat wo,ZalFloat hh,ZalFloat * pEa)
{
    ZalFloat ewt = exp(-wo*hh) ,tewt = hh* exp(-wo*hh),ttewt = hh* hh* exp(-wo*hh) /2 ;
    ZalFloat EJ[9] = { ewt,tewt,ttewt,     0,ewt,tewt,     0,0,ewt };
    ZalFloat V[9] = {wo*wo,-2*wo,1,    2*wo*wo*wo,-3*wo*wo,0,  wo*wo*wo*wo, -wo*wo*wo,0};
    ZalFloat IV[9] = {0,-1/wo/wo/wo,3/wo/wo/wo/wo,    0,-1/wo/wo,2/wo/wo/wo,  1, -1/wo,1/wo/wo};
    ZalFloat tmp[9] ={0};
    mat33Mupliply(V,EJ,tmp);
    mat33Mupliply(tmp,IV,pEa);
}

/*
ABO = [ A , B; O,I]
W, H = eig(ABO)
EABO = H * diag(exp(W * hh)) * inv(H)
EA = EABO[0:3, 0:3]
EB = EABO[0:3, 3:5]
*/ 
ZalVoid zalLesoInit(ZalLeso* pEso,ZalFloat wo,ZalFloat hh,ZalFloat b0)
{
    ZalFloat mB[6] ={0, 3*wo,b0  ,3*wo*wo,0, wo*wo*wo};
    ZalFloat iA[9] ={0,0,-1/wo/wo/wo, 	1,0,-3/wo/wo,		0,1,-3/wo};
    ZalFloat tmp[9] ={0},tmp2[9]={0};
    ZalFloat mI[9] ={1,0,0,    0,1,0,  0,0,1};
    pEso->zz[0] = 0;
    pEso->zz[1] = 0;
    pEso->zz[2] = 0;
    zalWodt2Exmpm(wo,hh,pEso->eA);
    //  EB = inv(A) * (EA-eye(3)) *B;
    mat33Minus(pEso->eA,mI,tmp);
    mat33Mupliply(iA,tmp,tmp2); 
    mat33Mupliply32(tmp2,mB,pEso->eB); 
};

//zz = EA * zz + EB * uy
ZalVoid zalLesoStep(ZalLeso* pEso,ZalFloat u,ZalFloat y)
{

    ZalFloat tmp[3],tmp2[3];
    ZalFloat uy[2] = { u,y};
    ZalInt32 i;
    mat33Mupliply31(pEso->eA,pEso->zz,tmp);
    mat32Mupliply21(pEso->eB,uy, tmp2);
    for (i=0;i<3;i++)
    {
        pEso->zz[i] =  tmp[i] + tmp2[i];
    }
};
ZalVoid zalLesoGetState(ZalLeso* pEso,ZalFloat * pOut)
{
    ZalInt32 i;
    for (i=0;i<3;i++)
    {
        pOut[i] = pEso->zz[i] ;
    }
};
